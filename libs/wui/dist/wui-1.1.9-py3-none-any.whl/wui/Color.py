class Color:
    White = "white"
    Blue = "blue"
    LightBlue = "light blue"
    Grey = "grey"
    LightGrey = "light grey"
    Black = "black"