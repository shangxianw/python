import wui

print(wui)