import tkinter as tk
from .EventBase import EventBase
from .StyleBase import StyleBase

class Group(tk.Frame, EventBase, StyleBase):
    pass
