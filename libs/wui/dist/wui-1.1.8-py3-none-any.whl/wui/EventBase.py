import tkinter as tk

class EventBase:
    # def addEventListener(self, type:str, cbFn):
    #     self.bind(type, cbFn)
    
    # def removeEventListener(self, type:str):
    #     self.unbind(type)
    pass